```python
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import re
import random

# ---------------- COLORS ---------------- #

BG = "#f6f8fc"
CARD = "#ffffff"
PRIMARY = "#5b6cff"
TEXT = "#2d3748"

# ---------------- WINDOW ---------------- #

root = tk.Tk()
root.title("STUDY PLANNER")
root.geometry("1000x700")
root.configure(bg=BG)

# ---------------- DATA ---------------- #

quotes = [
    "Small progress every day adds up.",
    "Consistency beats intensity.",
    "Focus on understanding, not memorizing.",
    "Success comes from disciplined preparation.",
    "One step at a time."
]

topics_db = {
    "compiler": [
        "Lexical Analysis",
        "Syntax Analysis",
        "Operator Precedence Parsing",
        "Shift Reduce Parsing",
        "Code Generation",
        "Optimization"
    ],
    "ai": [
        "Introduction to AI",
        "Search Algorithms",
        "Knowledge Representation",
        "Expert Systems",
        "Machine Learning Basics",
        "Neural Networks"
    ],
    "math": [
        "Algebra",
        "Functions",
        "Derivatives",
        "Integration",
        "Trigonometry",
        "Practice Problems"
    ],
    "physics": [
        "Motion",
        "Force",
        "Work and Energy",
        "Waves",
        "Electricity",
        "Numericals"
    ],
    "cyber": [
        "Cyber Threats",
        "Malware",
        "Phishing",
        "Network Security",
        "Firewalls",
        "Practice Questions"
    ]
}

# ---------------- FUNCTIONS ---------------- #

def clear_all():
    input_box.delete("1.0", tk.END)
    output_box.delete("1.0", tk.END)
    progress["value"] = 0
    stats_label.config(text="📊 Waiting for input...")

def save_plan():
    plan = output_box.get("1.0", tk.END)

    if not plan.strip():
        messagebox.showwarning("Warning", "Generate a plan first.")
        return

    file_path = filedialog.asksaveasfilename(
        defaultextension=".txt",
        filetypes=[("Text File", "*.txt")]
    )

    if file_path:
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(plan)

        messagebox.showinfo("Saved", "Study plan saved successfully.")

def detect_days(text):

    week_match = re.search(r'(\d+)\s*week', text)
    day_match = re.search(r'(\d+)\s*day', text)

    if week_match:
        return int(week_match.group(1)) * 7

    if day_match:
        return int(day_match.group(1))

    return 7

def detect_subjects(text):

    subjects = []

    for key in topics_db:
        if key in text:
            subjects.append(key)

    return subjects

def generate_plan():

    text = input_box.get("1.0", tk.END).strip().lower()

    if not text:
        messagebox.showerror(
            "Error",
            "Please describe your study goal."
        )
        return

    total_days = detect_days(text)

    subjects = detect_subjects(text)

    if not subjects:
        subjects = ["general"]

    study_days = max(1, int(total_days * 0.8))
    revision_days = total_days - study_days

    output_box.delete("1.0", tk.END)

    output_box.insert(
        tk.END,
        "\n📚 STUDY PLANNER\n"
    )

    output_box.insert(
        tk.END,
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n\n"
    )

    output_box.insert(
        tk.END,
        f"📅 Total Duration: {total_days} Days\n"
    )

    output_box.insert(
        tk.END,
        f"📘 Study Days: {study_days}\n"
    )

    output_box.insert(
        tk.END,
        f"🔁 Revision Days: {revision_days}\n\n"
    )

    stats_label.config(
        text=f"📊 Days: {total_days} | Subjects: {len(subjects)}"
    )

    day_count = 1

    for day in range(study_days):

        output_box.insert(
            tk.END,
            f"📅 DAY {day_count}\n"
        )

        daily_tasks = []

        for subject in subjects:

            if subject in topics_db:

                topic_list = topics_db[subject]

                topic = topic_list[
                    day % len(topic_list)
                ]

                daily_tasks.append(
                    f"📘 {subject.upper()} → {topic}"
                )

        random.shuffle(daily_tasks)

        for task in daily_tasks:
            output_box.insert(
                tk.END,
                f"   {task}\n"
            )

        if day % 2 == 0:
            output_box.insert(
                tk.END,
                "   📝 Practice Questions\n"
            )

        if day % 3 == 0:
            output_box.insert(
                tk.END,
                "   📄 Short Revision Session\n"
            )

        output_box.insert(
            tk.END,
            f"   💡 {random.choice(quotes)}\n\n"
        )

        day_count += 1

        progress["value"] = (
            (day_count / total_days) * 100
        )

        root.update_idletasks()

    for _ in range(revision_days):

        output_box.insert(
            tk.END,
            f"📅 DAY {day_count} (REVISION)\n"
        )

        output_box.insert(
            tk.END,
            "   🔁 Revise all important topics\n"
        )

        output_box.insert(
            tk.END,
            "   📝 Solve past papers\n"
        )

        output_box.insert(
            tk.END,
            "   🎯 Focus on weak areas\n"
        )

        output_box.insert(
            tk.END,
            f"   💡 {random.choice(quotes)}\n\n"
        )

        day_count += 1

    output_box.insert(
        tk.END,
        "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n"
    )

    output_box.insert(
        tk.END,
        "🎉 Good Luck!\n"
    )

    progress["value"] = 100

# ---------------- TITLE ---------------- #

title = tk.Label(
    root,
    text="STUDY PLANNER",
    font=("Segoe UI", 24, "bold"),
    bg=BG,
    fg=PRIMARY
)

title.pack(pady=15)

# ---------------- INPUT CARD ---------------- #

input_frame = tk.Frame(
    root,
    bg=CARD,
    bd=1,
    relief="solid"
)

input_frame.pack(
    fill="x",
    padx=20,
    pady=5
)

tk.Label(
    input_frame,
    text="Describe your study needs:",
    bg=CARD,
    fg=TEXT,
    font=("Segoe UI", 12, "bold")
).pack(anchor="w", padx=10, pady=8)

input_box = tk.Text(
    input_frame,
    height=6,
    font=("Segoe UI", 11),
    bg="white",
    fg=TEXT
)

input_box.pack(
    fill="x",
    padx=10,
    pady=10
)

# ---------------- BUTTONS ---------------- #

button_frame = tk.Frame(root, bg=BG)

button_frame.pack(pady=10)

generate_btn = tk.Button(
    button_frame,
    text="Generate Plan",
    command=generate_plan,
    bg=PRIMARY,
    fg="white",
    font=("Segoe UI", 11, "bold"),
    padx=15,
    pady=8
)

generate_btn.pack(side="left", padx=5)

clear_btn = tk.Button(
    button_frame,
    text="Clear",
    command=clear_all,
    bg="#ff6b6b",
    fg="white",
    font=("Segoe UI", 11, "bold"),
    padx=15,
    pady=8
)

clear_btn.pack(side="left", padx=5)

save_btn = tk.Button(
    button_frame,
    text="Save Plan",
    command=save_plan,
    bg="#2ecc71",
    fg="white",
    font=("Segoe UI", 11, "bold"),
    padx=15,
    pady=8
)

save_btn.pack(side="left", padx=5)

# ---------------- STATS ---------------- #

stats_label = tk.Label(
    root,
    text="📊 Waiting for input...",
    bg=BG,
    fg=TEXT,
    font=("Segoe UI", 10)
)

stats_label.pack()

# ---------------- PROGRESS ---------------- #

progress = ttk.Progressbar(
    root,
    orient="horizontal",
    mode="determinate",
    length=900
)

progress.pack(pady=10)

# ---------------- OUTPUT ---------------- #

output_frame = tk.Frame(
    root,
    bg=CARD,
    bd=1,
    relief="solid"
)

output_frame.pack(
    fill="both",
    expand=True,
    padx=20,
    pady=10
)

scrollbar = tk.Scrollbar(output_frame)

scrollbar.pack(
    side="right",
    fill="y"
)

output_box = tk.Text(
    output_frame,
    font=("Consolas", 10),
    bg="white",
    fg=TEXT,
    yscrollcommand=scrollbar.set
)

output_box.pack(
    fill="both",
    expand=True
)

scrollbar.config(
    command=output_box.yview
)

# ---------------- RUN ---------------- #

root.mainloop()
```
