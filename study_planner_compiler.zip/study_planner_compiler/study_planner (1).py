
import tkinter as tk
from tkinter import ttk, messagebox, filedialog
import re
import random

BG = "#bac9f4"
CARD = "#ffffff"
PRIMARY = "#5b6cff"
TEXT = "#030b1a"

quotes = [
    "Small progress every day adds up.",
    "Consistency beats intensity.",
    "Focus on understanding.",
    "Practice makes progress.",
    "Stay consistent and keep learning."
]

topics_db = {
    "compiler": ["Lexical Analysis","Syntax Analysis","Operator Precedence Parsing","Code Generation","Optimization"],
    "ai": ["Search Algorithms","Knowledge Representation","Machine Learning","Neural Networks"],
    "math": ["Algebra","Trigonometry","Derivatives","Integration"],
    "physics": ["Motion","Force","Energy","Electricity"],
    "cyber": ["Malware","Phishing","Network Security","Firewalls"]
}

def detect_days(text):
    week = re.search(r"(\\d+)\\s*week", text)
    day = re.search(r"(\\d+)\\s*day", text)
    if week:
        return int(week.group(1))*7
    if day:
        return int(day.group(1))
    return 7

def detect_subjects(text):
    found = [k for k in topics_db if k in text.lower()]
    return found if found else ["general"]

def clear_all():
    input_box.delete("1.0", tk.END)
    progress["value"] = 0
    for i in tree.get_children():
        tree.delete(i)

def save_plan():
    path = filedialog.asksaveasfilename(defaultextension=".txt")
    if not path:
        return
    with open(path, "w", encoding="utf-8") as f:
        for row in tree.get_children():
            f.write(" | ".join(map(str, tree.item(row)["values"])) + "\\n")
    messagebox.showinfo("Saved", "Plan saved successfully.")

def generate_plan():
    text = input_box.get("1.0", tk.END).strip().lower()
    if not text:
        messagebox.showerror("Error", "Please enter your study details.")
        return

    for i in tree.get_children():
        tree.delete(i)

    days = detect_days(text)
    subjects = detect_subjects(text)

    progress["value"] = 0

    for day in range(1, days + 1):
        if day > int(days * 0.8):
            tree.insert("", "end", values=(day, "Revision", "All Subjects",
                                           "Past Papers & Revision",
                                           random.choice(quotes)))
        else:
            subject = subjects[(day - 1) % len(subjects)]
            if subject in topics_db:
                task = topics_db[subject][(day - 1) % len(topics_db[subject])]
            else:
                task = "General Study Session"

            tree.insert("", "end", values=(day, "Study", subject.title(),
                                           task, random.choice(quotes)))

        progress["value"] = (day / days) * 100
        root.update_idletasks()

root = tk.Tk()
root.title("STUDY PLANNER")
root.geometry("1100x700")
root.configure(bg=BG)

title = tk.Label(root, text="STUDY PLANNER",
                 font=("Segoe UI", 24, "bold"),
                 bg=BG, fg=PRIMARY)
title.pack(pady=10)

frame = tk.Frame(root, bg=CARD)
frame.pack(fill="x", padx=15, pady=10)

tk.Label(frame, text="Describe your study goal:",
         bg=CARD, fg=TEXT,
         font=("Segoe UI", 11, "bold")).pack(anchor="w", padx=10, pady=5)

input_box = tk.Text(frame, height=5, font=("Segoe UI", 11))
input_box.pack(fill="x", padx=10, pady=10)

btn_frame = tk.Frame(root, bg=BG)
btn_frame.pack(pady=5)

tk.Button(btn_frame, text="Generate Plan", bg=PRIMARY, fg="white",
          command=generate_plan).pack(side="left", padx=5)

tk.Button(btn_frame, text="Clear", bg="#8c0c0c", fg="white",
          command=clear_all).pack(side="left", padx=5)

tk.Button(btn_frame, text="Save Plan", bg="#13a04e", fg="white",
          command=save_plan).pack(side="left", padx=5)

progress = ttk.Progressbar(root, length=1000, mode="determinate")
progress.pack(pady=10)

tree_frame = tk.Frame(root)
tree_frame.pack(fill="both", expand=True, padx=15, pady=10)

cols = ("Day", "Type", "Subject", "Task", "Note")
tree = ttk.Treeview(tree_frame, columns=cols, show="headings")

for c in cols:
    tree.heading(c, text=c)
    tree.column(c, width=180)

ys = ttk.Scrollbar(tree_frame, orient="vertical", command=tree.yview)
tree.configure(yscrollcommand=ys.set)

ys.pack(side="right", fill="y")
tree.pack(fill="both", expand=True)

root.mainloop()
